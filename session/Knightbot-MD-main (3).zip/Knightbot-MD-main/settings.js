const settings = {
  packname: 'Knight Bot',
  author: '‎',
  botName: "Knight Bot",
  botOwner: 'Sunepa', // Your name
  ownerNumber: '2349052369671', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "private",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.1.1",
};

module.exports = settings;
